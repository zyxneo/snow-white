# TODO

* fix build
* remove internalization
* rename graph files
* 7
* linkek gyűjteménye
